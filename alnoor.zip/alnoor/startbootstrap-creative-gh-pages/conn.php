<?php

require_once ('MysqliDb.php');
$db = new MysqliDb ('localhost', 'recru', '1234qwerA', 'recru');

